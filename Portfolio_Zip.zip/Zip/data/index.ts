export const personal = {
  name: "Pawan Tripathi",
  Status: "Available",
  role: "Frontend Developer",
  location: "Uttarakhand, India",
  email: "tripathipawan8705@gmail.com",
  phone: "+91 6396096431",
  bio: "Passionate Frontend Developer crafting pixel-perfect, high-performance web applications. I blend clean code with creative design — turning complex ideas into seamless digital experiences.",
  Aboutbio: "I'm Pawan Tripathi, a passionate Frontend Developer from Uttarakhand, India, currently pursuing my BCA at MAHGU. I specialize in building responsive, pixel-perfect web applications using React.js, TypeScript, and Tailwind CSS. With 75+ projects and a strong eye for UI/UX, I blend clean code with creative design to craft seamless digital experiences. Beyond coding, I run Tripathi Dev Lab — a YouTube channel where I share web dev tutorials and insights with the developer community. I'm always exploring the latest in frontend tech, AI dev tools, and open-source — and I'm currently open to freelance projects and exciting opportunities.",
  status: "Open to Opportunities",
}

export const Resume = {
  link: "https://drive.google.com/file/d/1mROYY22_Ka89YtnLvXdvBaiXwuZhaCrv/view?usp=drivesdk",
}

export const phrases = [
  "Frontend Developer",
  "React.js Specialist",
  "UI/UX Enthusiast",
  "JavaScript Aficionado",
  "AI Tools Explorer",
  "Tailwind CSS Expert",
  "Open Source Contributor",
]

export const socials = [
  { name: "GitHub", icon: "FaGithub", url: "https://github.com/tripathipawan", color: "#939393" },
  { name: "LinkedIn", icon: "FaLinkedin", url: "https://www.linkedin.com/in/pawantripathi", color: "#0A66C2" },
  { name: "YouTube", icon: "FaYoutube", url: "https://youtube.com/@tripathidevlab", color: "#FF0000" },
  { name: "Instagram", icon: "FaInstagram", url: "https://www.instagram.com/tripathidevlab", color: "#E1306C" },
  { name: "Leetcode", icon: "SiLeetcode", url: "https://leetcode.com/u/hK10OqCKbH/", color: "#aaaaaa" },
  { name: "WhatsApp", icon: "FaWhatsapp", url: "https://whatsapp.com/channel/0029Vb7sg2V3bbV4NpadBX1m", color: "#25D366" },
  { name: "FaceBook", icon: "FaFacebook", url: "https://www.facebook.com/profile.php?id=61572586097410", color: "#1877F2" },
]

export const stats = [
  { value: "70+", label: "Projects" },
  { value: "65+", label: "Repositories" },
  { value: "25+", label: "Technologies" },
]

export const skillCategories = [
  {
    cat: "Frontend Core", icon: "💻", color: "#6366f1",
    skills: ["HTML5", "CSS3", "JavaScript (ES6+)", "TypeScript", "Responsive Design", "Web APIs"],
  },
  {
    cat: "React Ecosystem", icon: "⚛️", color: "#38bdf8",
    skills: ["React.js", "React Router", "React Hooks", "Context API", "Redux Toolkit", "Zustand", "React Query", "Custom Hooks"],
  },
  {
    cat: "Styling & UI", icon: "🎨", color: "#10d9a0",
    skills: ["Tailwind CSS v4", "Framer Motion", "GSAP", "ShadCN UI", "Material UI", "Bootstrap", "CSS Animations", "Neuromorphic UI"],
  },
  {
    cat: "Tools & Platforms", icon: "🛠️", color: "#f59e0b",
    skills: ["Git", "GitHub", "VS Code", "Vite", "Webpack", "npm", "Vercel", "Netlify"],
  },
  {
    cat: "Backend & Services", icon: "🔥", color: "#f472b6",
    skills: ["Firebase Auth", "Firestore", "REST APIs", "Axios"],
  },
  {
    cat: "AI Dev Tools", icon: "🤖", color: "#a78bfa",
    skills: ["Claude AI", "Lovable.dev", "Emergent", "Replit", "GitHub Copilot", "Cursor AI", "v0 by Vercel", "Bolt.new"],
  },
]

export const projects = [
  {
    id: 1, emoji: "👨", title: "Personal Portfolio", featured: true,
    desc: "Personal portfolio showcasing projects, skills, and experience using React, responsive UI, modern styling, and smooth interactions.",
    tech: ["JavaScript", "React.js", "Tailwind CSS", "Lucide React", "React Icons"],
    github: "https://github.com/tripathipawan/My_Personal_Portfolio",
    live: "https://pawantripathi.vercel.app/",
    color: "#12c600",
  },{
    id: 2, emoji: "🤖", title: "Access Copilot", featured: true,
    desc: "AccessCopilot is an AI-powered web accessibility auditing tool.",
    tech: ["TypeScript", "Tailwind CSS", "React.js", "Framer Motion", "Redux Toolkit"],
    github: "https://github.com/tripathipawan/Accessibility_Copilot",
    live: "https://accesscopilot.vercel.app/",
    color: "#38bdf8",
  },
  {
    id: 3, emoji: "🏥", title: "Doctor Appointment Booking App", featured: true,
    desc: "Doctor appointment booking with Firebase auth, real-time Firestore, light/dark mode, and fully responsive UI.",
    tech: ["JavaScript", "React.js", "Tailwind CSS", "Firebase", "Firestore", "Lucide Icons"],
    github: "https://github.com/tripathipawan/Doctor_Booking_App",
    live: "https://appoint-your-doctor.vercel.app/",
    color: "#7510ff",
  },
  {
    id: 4, emoji: "🛍️", title: "Nova Shop", featured: true,
    desc: "Modern e-commerce frontend with product listings, cart management, filter and sleek responsive design.",
    tech: ["JavaScript", "React.js", "Tailwind CSS", "Context API", "Axios", "Lucide Icons", "Framer Motion", "Slick-carousel", "Clerk"],
    github: "https://github.com/tripathipawan/Nova_Shop/",
    live: "https://knovashop.vercel.app/",
    color: "#ffe000",
  },

  {
    id: 5, emoji: "🌈", title: "Color Pallate website", featured: false,
    desc: "Pixel-perfect Nike landing page with smooth animations and premium feel showcasing advanced Tailwind.",
    tech: ["JavaScript", "React.js", "Tailwind CSS", "Framer Motion", "Lucide Icons"],
    github: "https://github.com/tripathipawan/Color_Picker_Website",
    live: "https://paletteflow-studio.vercel.app/",
    color: "#f43f5e",
  },
  {
    id: 6, emoji: "👟", title: "Nike Landing Page", featured: false,
    desc: "Pixel-perfect Nike landing page with smooth animations and premium feel showcasing advanced Tailwind.",
    tech: ["JavaScript", "React.js", "Tailwind CSS", "Framer Motion", "Lucide Icons"],
    github: "https://github.com/tripathipawan/Nike",
    live: "https://nike-eta-beryl.vercel.app/",
    color: "#f59e0b",
  },
  {
    id: 7, emoji: "📊", title: "Projects Showcase Website", featured: true,
    desc: "Multiple Projects Showcase Website with responsive design and smooth animations.",
    tech: ["HTML5", "CSS3", "JavaScript", "Bootstrap"],
    github: "https://github.com/tripathipawan/",
    live: "https://manyprojects.netlify.app/",
    color: "#38bdf8",
  },

]

export const experience = [
  {
    id: 1,
    role: "Frontend Developer",
    company: "Tripathi Dev Lab",
    period: "2025 – Present",
    type: "Self-Initiative",
    current: true,
    desc: 'Running "Tripathi Dev Lab" — building full-featured web apps, sharing knowledge on YouTube, growing developer community.',
    tags: ["JavaScript", "TypeScript", "React.js", "GSAP", "Framer Motion", "AI Tools"],
  },
]

export const education = [
  {
    id: 1,
    degree: "Bachelor of Computer Applications (BCA)",
    school: "Maharaja Agrasen Himalayan Garhwal University (MAHGU)",
    loc: "Uttarakhand, India",
    period: "2022 – 2025",
    desc: "Bachelor of Computer Applications with a strong foundation in programming, data structures, web dev, and software engineering.",
    tags: ["Data Structures", "Python", "Web Dev", "OOPs", "Software Engineering"],
    grade: "8.03 CGPA",
  },
  {
    id: 2,
    degree: "Intermediate (12th) — PCM",
    school: "Rana Pratap Inter College (U.K Board)",
    loc: "Uttarakhand, India",
    period: "2021 – 2022",
    desc: "Completed Class 12 (PCM) with a strong foundation in mathematics, logical reasoning, and problem-solving.",
    tags: ["Physics", "Chemistry", "Mathematics"],
    grade: "74%",
  },
  {
    id: 3,
    degree: "High School (10th) — Mathematics",
    school: "Guru Nanak Public School (U.K Board)",
    loc: "Uttarakhand, India",
    period: "2019 – 2020",
    desc: "Completed Class 10 with Mathematics, building a strong base in numerical and logical thinking.",
    tags: ["Mathematics", "Science", "English", "Social Science",],
    grade: "79%",
  },
]

export const certifications = [
  {
    id: 1,
    name: "JavaScript — The Complete Guide",
    platform: "CodeChef",
    year: "2024",
    color: "#f59e0b",
    icon: "🏅",
    URL: "https://www.codechef.com/certificates/public/5292983",
  },
]